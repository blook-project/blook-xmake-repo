blook-registry-selftest 0.1.0 - fixture artifact used by .github/workflows/validate.yml
