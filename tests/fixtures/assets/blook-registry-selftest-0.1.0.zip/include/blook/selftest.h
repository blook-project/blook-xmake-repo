#pragma once
// blook-xmake-repo self-test package header (not part of any product SDK)
inline int blook_selftest_answer() { return 42; }
